from django.contrib import admin

from programs.models import Program

admin.site.register(Program)